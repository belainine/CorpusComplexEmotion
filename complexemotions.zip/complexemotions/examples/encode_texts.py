# -*- coding: utf-8 -*-

""" Use torchMoji to encode texts into emotional feature vectors.
"""
from __future__ import print_function, division, unicode_literals
import json
import matplotlib.pyplot as plt
import numpy as np

from torchmoji.sentence_tokenizer import SentenceTokenizer
from torchmoji.model_def import torchmoji_feature_encoding
from torchmoji.global_variables import PRETRAINED_PATH, VOCAB_PATH

TEST_SENTENCES = ['I love mom\'s cooking',
                  'I love how you never reply back..',
                  'I love cruising with my homies',
                  'I love messing with yo mind!!',
                  'I love you and now you\'re just gone..',
                  'This is shit',
                  'This is the shit']

maxlen = 30
batch_size = 32

print('Tokenizing using dictionary from {}'.format(VOCAB_PATH))
with open(VOCAB_PATH, 'r') as f:
    vocabulary = json.load(f)
st = SentenceTokenizer(vocabulary, maxlen)
tokenized, infos, wordgenstats = st.tokenize_sentences(TEST_SENTENCES)


print('Loading model from {}.'.format(PRETRAINED_PATH))
model = torchmoji_feature_encoding(PRETRAINED_PATH, return_attention=True)
print(model)

print('Encoding texts..')
encoding,att= model(tokenized)

print('First 5 dimensions for sentence: {}'.format(TEST_SENTENCES[0]))
print(encoding[0,:5])
print(len(encoding[0,:]))

print('tokenized',wordgenstats)

def samplemat(dims):
    """Make a matrix with all zeros and increasing elements on the diagonal"""
    aa = np.zeros(dims)
    for i in range(min(dims)):
        aa[i, i] = i
    return aa
s_tokens=[ s_words for s_words, s_info in st.wordgen]
     
print(s_tokens)
labelx = ["cucumber", "tomato", "lettuce", "asparagus",
                  "potato", "wheat", "barley"]
labely = ["Farmer Joe", "Upland Bros.", "Smith Gardening",
               "Agrifun", "Organiculture", "BioGoods Ltd.", "Cornylee Corp."]

def showAttention(att,labelx,labely):

    fig, ax = plt.subplots()
    # Display matrix
    print(att.data.cpu().numpy())
    
    shape=att.data.cpu().numpy().shape
    print(shape)
    ax.matshow(att.data.cpu().numpy())
    
    ax.set_xticks(np.arange(len(labely)))
    
    ax.set_yticks(np.arange(len(labelx)))
    ax.set_xticklabels(labely)
    
    ax.set_yticklabels(labelx)
    fig.tight_layout()
    # Loop over data dimensions and create text annotations.
    for i in range(shape[0]):
        for j in range(shape[1]):
            text = ax.text(j, i, int(att.data.cpu().numpy()[i, j]*100),
                           ha="center", va="center", color="w")
    # Rotate the tick labels and set their alignment.
    plt.setp(ax.get_xticklabels(), rotation=-45,  ha="right",
             rotation_mode="anchor")
    
    #plt.title("Harvest of local farmers (in tons/year)")
    plt.show()
for labely in s_tokens:
    showAttention(att,labelx,labely)
# Now you could visualize the encodings to see differences,
# run a logistic regression classifier on top,
# or basically anything you'd like to do.