# -*- coding: utf-8 -*-
"""
Created on Sat Jan  5 16:27:53 2019

@author: belainine
"""

import numpy as np


def norm(v):
    return v / np.sqrt((np.sum(v**2)))
def softmax(x):
    """Compute softmax values for each sets of scores in x."""
    e_x = np.exp(x - np.max(x))
    return e_x / e_x.sum()
def getPosEmotions(e):
    a=[  1, 1, 0, 0,
         0, 1, 1, 0,
         0, 0, 1, 1,  
        -1, 0, 0, 1,
        -1,-1, 0, 0,
         0,-1,-1, 0,
         0, 0,-1,-1,
         1, 0, 0,-1 ]
    
    b= [ 1, 0, 1, 0, 
         0, 1, 0, 1, 
        -1, 0, 1, 0, 
         0,-1, 0, 1, 
        -1, 0,-1, 0, 
         0,-1, 0,-1, 
         1, 0,-1, 0, 
         0, 1, 0,-1 ]
    
    c= [ 1, 0, 0, 1,
        -1, 1, 0, 0, 
         0,-1, 1, 0, 
         0, 0,-1, 1,
        -1, 0, 0,-1,
         1,-1, 0, 0,
         0, 1,-1, 0,         
         0, 0, 1,-1 ]
         
    a=np.array(a)
    a.shape=(8,4)
    b=np.array(b)
    b.shape=(8,4)
    c=np.array(c)
    c.shape=(8,4)
    dyP=a.dot(np.array(e))>1
    dyS=b.dot(np.array(e))>1
    dyT=c.dot(np.array(e))>1
    return dyP,dyS,dyT
def getPrimaryEmotions(e):
    axis= [ "Anticipation_Surprise" , "Joy_Sadness"   , "Trust_Disgust" , "Fear_Anger"]

    #v1,v2,v3=getPosEmotions(e)
    return {'Basic Emotions':[  axis[i].split('_')[0] if e[i]==1  else axis[i].split('_')[1] if e[i]==-1 else 'No' for i in range(len(e))]}
def getEmotions(e):
    axis= [ "Anticipation_Surprise" , "Joy_Sadness"   , "Trust_Disgust" , "Fear_Anger"]
    Emotions_avances={ "Dyade primaire" :["Optimisme","Amour","Soumission","Crainte","Désappointement","Remord","mépris","Agressivité"],
      "Dyade secondaire" :["Fatalisme","Culpabilité","Curiosité","Désespoir","Horreur","Envie","Cynisme","Fierté"],
      "Dyade tertiaire" :["Anxiété","Ravissement","Fadeur",
                          "Honte",
                          "Indignation"
                          ,"Pessimisme"
                          ,"Morbidité"
                          ,'Domination'
                          ]}
    v1,v2,v3=getPosEmotions(e)
   
    return {'Dyade primaire':[Emotions_avances['Dyade primaire'][i] for i in range(len(v1)) if v1[i]],
        "Dyade secondaire": [Emotions_avances['Dyade secondaire'][i] for i in range(len(v2)) if v2[i]],
        'Dyade tertiaire':[Emotions_avances['Dyade tertiaire'][i] for i in range(len(v3)) if v3[i]]
    }
e=[-1,-1,-1,-1]
print(getPrimaryEmotions(e))
print( getEmotions(e))
    
    
