# -*- coding: utf-8 -*-
"""
Created on Sat Jan  5 21:26:32 2019

@author: belainine
"""

from nltk.corpus import wordnet
from nltk.corpus import wordnet as wn
import nltk
from nltk.tokenize import MWETokenizer,word_tokenize
import json
nltk.download('wordnet')
nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')
nltk.download('brown')
nltk.download('universal_tagset')
wn.synsets('dog') # doctest: +ELLIPSIS +NORMALIZE_WHITESPACE
'''
wn.synsets('ashamed', pos=wn.VERB)

wn.synsets('love', pos=wn.VERB)[2].examples()

wn.synsets('love', pos=wn.VERB)[0].hypernyms()

wn.synsets('love', pos=wn.VERB)[0].hyponyms()

wn.synsets('love', pos=wn.VERB)[0].member_holonyms()

wn.synset('good.a.01').lemmas()[0].antonyms()


synonyms = []= []
antonyms = []= []

for syn in wordnet.synsets("love"):
    for l in syn.lemmas():
        synonyms.append(l.name())
        if l.antonyms():
            antonyms.append(l.antonyms()[0].name())

print(set(synonyms))
print(set(antonyms))
'''
tokenizer = MWETokenizer([("i'am", "d'oeuvre")], separator='_')
str='In a little or a little bit or a lot in spite of'.replace('â€™',"'").replace('``'," ")
tokenizer.tokenize(str.split())
with open('vocabulary.json', encoding='utf-8') as data_file:
    data = json.loads(data_file.read())
    
def getNewSentenses(string):
    text = word_tokenize ( string)
    listofresult=list()
    listofresult.append(text)
    words_pos=nltk.pos_tag (text,tagset='universal')

    for i in range(len(words_pos)):
        w,p=words_pos[i]
        pos=wn.NOUN
        if p[0]=='V' or p=='CONJ':
            pos=wn.VERB
        elif p=='ADJ':
            pos=wn.ADJ
        elif p=='ADV':
            pos=wn.ADV
        else:
            pos=wn.NOUN
        Synsets=set()
        for Synset1 in wn.synsets(w, pos=pos):
            if len(wn.synsets(w, pos=pos))> 0 :
                Synsets=Synsets|{i   for i in Synset1.lemma_names()}
                
        for term in Synsets:
            #print(term,w)
            
            
            #print(Synset.examples())
            if  term in data.keys():
                result=words_pos[0:i]+[(term.replace('_',' '),p)]+words_pos[i+1:]
                print(' '.join(wr for wr,ps in result),term,pos)
                listofresult.append(' '.join(wr for wr,ps in result))
    print(len(listofresult))
    return listofresult
getNewSentenses("i'll be glad" )
getNewSentenses("i am content" )
getNewSentenses("i am joy" )
getNewSentenses("i am satisfied" )
getNewSentenses("wow that's nice" )
getNewSentenses("that's nice is over" )